

    // DOM Elements
    const menuToggle = document.querySelector('.menu-toggle');
    const navMenu = document.querySelector('.nav-menu');
    const header = document.querySelector('header');
    const languageLinks = document.querySelectorAll('.language-selector a');
    const body = document.body;

    // Mobile Menu Toggle
    document.addEventListener('DOMContentLoaded', function () {
        const menuToggle = document.querySelector('.menu-toggle');
        const navMenu = document.querySelector('.nav-menu');
    
        // Toggle menu visibility
        if (menuToggle && navMenu) {
            menuToggle.addEventListener('click', function () {
                navMenu.classList.toggle('active');
                menuToggle.classList.toggle('open');
            });
    
            // Close menu when clicking outside of it
            document.addEventListener('click', function (event) {
                if (!event.target.closest('.nav-menu') && !event.target.closest('.menu-toggle')) {
                    navMenu.classList.remove('active');
                    menuToggle.classList.remove('open');
                }
            });
    
            // Close menu when clicking a nav link
            navMenu.querySelectorAll('a').forEach(link => {
                link.addEventListener('click', () => {
                    navMenu.classList.remove('active');
                    menuToggle.classList.remove('open');
                });
            });
        }
    });

    // Language Switching
    const savedLanguage = localStorage.getItem('preferredLanguage') || 'en';
    changeLanguage(savedLanguage);

    languageLinks.forEach(link => {
        link.addEventListener('click', function (e) {
            e.preventDefault();
            const lang = this.getAttribute('data-lang');
            changeLanguage(lang);
            languageLinks.forEach(l => l.classList.remove('active'));
            this.classList.add('active');
            localStorage.setItem('preferredLanguage', lang);
        });
    });

    if (languageLinks) {
        languageLinks.forEach(link => {
            if (link.getAttribute('data-lang') === savedLanguage) link.classList.add('active');
        });
    }

    function changeLanguage(lang) {
        localStorage.setItem('preferredLanguage', lang);
        const elements = document.querySelectorAll('[data-lang-en], [data-lang-nl], [data-lang-fr], [data-lang-ro]');
        elements.forEach(element => {
            const translation = element.getAttribute(`data-lang-${lang}`) || element.getAttribute('data-lang-en'); // Fallback to English
            if (element.tagName === 'INPUT' || element.tagName === 'TEXTAREA') {
                if (element.type !== 'submit' && element.type !== 'button') {
                    element.placeholder = translation;
                } else {
                    element.value = translation;
                }
            } else {
                element.textContent = translation;
            }
        });
    }

    // Smooth Scrolling for Anchor Links
    document.querySelectorAll('a[href^="#"]').forEach(anchor => {
        anchor.addEventListener('click', function (e) {
            e.preventDefault();
            const target = document.querySelector(this.getAttribute('href'));
            if (target) {
                window.scrollTo({
                    top: target.offsetTop - 100,
                    behavior: 'smooth'
                });
            }
        });
    });

    // Header Scroll Effect
    window.addEventListener('scroll', () => {
        if (window.scrollY > 50) {
            header.classList.add('scrolled');
        } else {
            header.classList.remove('scrolled');
        }
    });

    // Back-to-Top Button
    const backToTop = document.createElement('button');
    backToTop.innerHTML = '<i class="fas fa-arrow-up"></i>';
    backToTop.className = 'back-to-top';
    body.appendChild(backToTop);

    backToTop.addEventListener('click', () => {
        window.scrollTo({ top: 0, behavior: 'smooth' });
    });

    window.addEventListener('scroll', () => {
        backToTop.style.display = window.scrollY > 300 ? 'block' : 'none';
    });

    // Scroll Progress Indicator
    const progressBar = document.createElement('div');
    progressBar.className = 'scroll-progress';
    body.appendChild(progressBar);

    window.addEventListener('scroll', () => {
        const totalHeight = document.body.scrollHeight - window.innerHeight;
        const progress = (window.scrollY / totalHeight) * 100;
        progressBar.style.width = `${progress}%`;
    });

    // Preload Images for Performance
    const imagesToPreload = [
        'img/hero-bg.jpg',
        'img/oil-gas.jpg',
        'img/chemical.jpg',
        'img/power.jpg',
        'img/proeng-logo.png',
    ];
    imagesToPreload.forEach(src => {
        const img = new Image();
        img.src = src;
    });

    // Lazy Load Images
    const lazyImages = document.querySelectorAll('img[data-src]');
    const imageObserver = new IntersectionObserver((entries, observer) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                const img = entry.target;
                img.src = img.getAttribute('data-src');
                img.removeAttribute('data-src');
                observer.unobserve(img);
            }
        });
    });
    lazyImages.forEach(img => imageObserver.observe(img));


document.addEventListener('DOMContentLoaded', () => {
    const cookieConsent = document.getElementById('cookie-consent');
    const acceptCookiesButton = document.getElementById('accept-cookies');

    function setCookie(name, value, days) {
        const expires = new Date(Date.now() + days * 864e5).toUTCString();
        document.cookie = `${name}=${encodeURIComponent(value)}; expires=${expires}; path=/; SameSite=Lax`; // Default to Lax
    }

    function getCookie(name) {
        return document.cookie.split('; ').reduce((r, c) => {
            const [key, val] = c.split('=');
            return key === name ? decodeURIComponent(val) : r;
        }, '');
    }

    if (!getCookie('cookiesAccepted')) cookieConsent.style.display = 'block';

    acceptCookiesButton.addEventListener('click', () => {
        setCookie('cookiesAccepted', 'true', 30);
        cookieConsent.style.display = 'none';
    });
});

// Initialize AOS animation library
document.addEventListener('DOMContentLoaded', function () {
    AOS.init({
        duration: 800,
        easing: 'ease-in-out',
        once: true,
        offset: 100 // Triggers slightly earlier
    });


    // Language switcher
    const savedLanguage = localStorage.getItem('preferredLanguage') || 'en';
    document.getElementById('language-select').value = savedLanguage;
    changeLanguage(savedLanguage);

    // Preload images for better performance
    const imagesToPreload = [
        'img/hero-bg.jpg',
        'img/team/john-doe.jpg',
        'img/team/jane-smith.jpg',
        'img/team/emily-johnson.jpg',
        'img/proeng-logo.png',
        'img/oil-gas.jpg',
        'img/chemical.jpg',
        'img/power.jpg',
    ];

    imagesToPreload.forEach((imageSrc) => {
        const img = new Image();
        img.src = imageSrc;
    });
});

// Language switcher functionality
function changeLanguage(lang) {
    if (!lang) {
        lang = document.getElementById('language-select').value;
    }

    localStorage.setItem('preferredLanguage', lang);
    const elements = document.querySelectorAll(`[data-lang-${lang}]`);

    elements.forEach((element) => {
        const translation = element.getAttribute(`data-lang-${lang}`);
        if (element.tagName === 'INPUT' || element.tagName === 'TEXTAREA') {
            if (element.type !== 'submit' && element.type !== 'button') {
                element.placeholder = translation;
            } else {
                element.value = translation;
            }
        } else {
            element.textContent = translation;
        }
    });
}

// Language selector click event
document.querySelectorAll('.language-selector a').forEach((link) => {
    link.addEventListener('click', function(e) {
        e.preventDefault();
        const lang = this.getAttribute('data-lang');
        changeLanguage(lang);
    });
});

document.addEventListener('DOMContentLoaded', function () {
    // Existing code (hamburger menu, language switching, etc.) remains here...

    // Portfolio Details Toggle
    const viewDetailsButtons = document.querySelectorAll('.view-details-btn');
    viewDetailsButtons.forEach(button => {
        button.addEventListener('click', function () {
            const details = this.nextElementSibling; // Targets .portfolio-details
            const isOpen = details.style.maxHeight && details.style.maxHeight !== '0px';

            if (isOpen) {
                details.style.maxHeight = '0px';
                this.textContent = this.getAttribute('data-lang-' + (localStorage.getItem('preferredLanguage') || 'en')) || 'View Details';
                this.classList.remove('active');
            } else {
                // Set max-height to content height for smooth transition
                details.style.maxHeight = details.scrollHeight + 'px';
                this.textContent = this.getAttribute('data-lang-' + (localStorage.getItem('preferredLanguage') || 'en')).replace('View', 'Hide') || 'Hide Details';
                this.classList.add('active');
            }
        });
    });

    // Ensure language switching updates button text
    function updateButtonText() {
        viewDetailsButtons.forEach(button => {
            const lang = localStorage.getItem('preferredLanguage') || 'en';
            const isOpen = button.classList.contains('active');
            button.textContent = isOpen
                ? button.getAttribute('data-lang-' + lang).replace('View', 'Hide')
                : button.getAttribute('data-lang-' + lang);
        });
    }

    // Call updateButtonText on language change
    const languageLinks = document.querySelectorAll('.language-selector a');
    languageLinks.forEach(link => {
        link.addEventListener('click', function () {
            updateButtonText();
        });
    });

    // Initial text update based on saved language
    updateButtonText();
});
